# Minimal static web server (no install needed) so the camera works on http://localhost.
$port = 8777
$root = (Get-Location).Path
$mime = @{ '.html'='text/html; charset=utf-8'; '.js'='text/javascript'; '.css'='text/css';
          '.webp'='image/webp'; '.png'='image/png'; '.jpg'='image/jpeg'; '.jpeg'='image/jpeg';
          '.mp3'='audio/mpeg'; '.json'='application/json'; '.svg'='image/svg+xml' }
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")
try { $listener.Start() } catch {
  Write-Host ""
  Write-Host "起動できませんでした（ポート $port が使用中かもしれません）。"
  Write-Host "開いている別のウィンドウを閉じてから、もう一度お試しください。"
  Read-Host "Enterで終了"; exit 1
}
Write-Host "HAND DANMAKU を起動中... ブラウザが開きます。"
Write-Host "遊び終わったら、この黒い画面を閉じてください。"
Start-Process "http://localhost:$port/index.html"
while ($listener.IsListening) {
  try {
    $ctx = $listener.GetContext()
    $rel = [System.Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath.TrimStart('/'))
    if ($rel -eq '') { $rel = 'index.html' }
    $path = Join-Path $root $rel
    if (Test-Path $path -PathType Leaf) {
      $bytes = [System.IO.File]::ReadAllBytes($path)
      $ext = [System.IO.Path]::GetExtension($path).ToLower()
      if ($mime.ContainsKey($ext)) { $ctx.Response.ContentType = $mime[$ext] }
      $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    } else { $ctx.Response.StatusCode = 404 }
    $ctx.Response.Close()
  } catch { }
}
