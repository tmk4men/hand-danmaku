#!/bin/bash
cd "$(dirname "$0")"
echo 'HAND DANMAKU を起動中... ブラウザが開きます。終わったらこのウィンドウを閉じてください。'
( sleep 1; (open 'http://localhost:8777/index.html' 2>/dev/null || xdg-open 'http://localhost:8777/index.html' 2>/dev/null) ) &
python3 -m http.server 8777 2>/dev/null || python -m http.server 8777
